def load_data():
    # Load FaceForensics++ or custom dataset
    # Return PyTorch DataLoader objects
    pass
